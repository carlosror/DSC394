"""
Implement the following models for classification.

Feel free to modify the arguments for each of model's __init__ function.
This will be useful for tuning model hyperparameters such as hidden_dim, num_layers, etc,
but remember that the grader will assume the default constructor!
"""

from pathlib import Path

import torch
import torch.nn as nn 
from typing import List, Union

class ClassificationLoss(nn.Module):
    def forward(self, logits: torch.Tensor, target: torch.LongTensor) -> torch.Tensor:
        """
        Multi-class classification loss
        Hint: simple one-liner

        Args:
            logits: tensor (b, c) logits, where c is the number of classes
            target: tensor (b,) labels

        Returns:
            tensor, scalar loss
        """
        #raise NotImplementedError("ClassificationLoss.forward() is not implemented")
        log_probs = torch.nn.functional.log_softmax(logits, dim=1)
        criterion = nn.NLLLoss()
        loss = criterion(log_probs, target)
        return loss


class LinearClassifier(nn.Module):
    def __init__(
        self,
        h: int = 64,
        w: int = 64,
        num_classes: int = 6,
    ):
        """
        Args:
            h: int, height of the input image
            w: int, width of the input image
            num_classes: int, number of classes
        """
        super().__init__()

        #raise NotImplementedError("LinearClassifier.__init__() is not implemented")
        #super(MultiClassClassifier, self).__init__()
        self.fc = nn.Linear(h*w*3, num_classes, bias=True)
        #torch.nn.Linear(in_features=size[0] * size[1] * 3, out_features=1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: tensor (b, 3, H, W) image

        Returns:
            tensor (b, num_classes) logits
        """
        #raise NotImplementedError("LinearClassifier.forward() is not implemented")
        # 1. Flatten the image from (batch, 3, H, W) to (batch, 3 * H * W)
        x = x.flatten(start_dim=1)  # Alternatively: x.view(x.size(0), -1)
        
        # 2. Pass through the linear layer (computes xW^T + b automatically)
        logits = self.fc(x)
        #x = self.fc(x)
        x = torch.nn.functional.softmax(logits, dim=1)
        return logits


class MLPClassifier(nn.Module):
    def __init__(
        self,
        h: int = 64,
        w: int = 64,
        num_classes: int = 6,
    ):
        """
        An MLP with a single hidden layer

        Args:
            h: int, height of the input image
            w: int, width of the input image
            num_classes: int, number of classes
        """
        super().__init__()
        layers = []
        # Add hidden layers
        #n_in = h * w * 3
        #hidden_size=[6]
        #for n_out in hidden_size:
        #    layers.append(torch.nn.Linear(n_in, n_out))
        #    layers.append(torch.nn.ReLU())
        #    n_in = n_out
        # Add the output layer
        #layers.append(torch.nn.Linear(n_out, 1))

        # Use torch.nn.Sequential to create a small model,
        # where the layers are connected in a cascading way.
        # The order they are passed in the constructor
        #self.network = torch.nn.Sequential(*layers)

        #raise NotImplementedError("MLPClassifier.__init__() is not implemented")
        n_in = h * w * 3
        
        hidden_size = 96
        # Constructing the network using nn.Sequential
        self.network = nn.Sequential(
            nn.Linear(n_in, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, num_classes)  # Matches num_classes
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: tensor (b, 3, H, W) image

        Returns:
            tensor (b, num_classes) logits
        """
        #raise NotImplementedError("MLPClassifier.forward() is not implemented")
        x = x.flatten(1) 
        
        return self.network(x)


class MLPClassifierDeep(nn.Module):
    def __init__(
        self,
        h: int = 64,
        w: int = 64,
        num_classes: int = 6,
        num_layers: int = 4,
        hidden_dim: int = 128,
    ):
        """
        An MLP with multiple hidden layers

        Args:
            h: int, height of image
            w: int, width of image
            num_classes: int

        Hint - you can add more arguments to the constructor such as:
            hidden_dim: int, size of hidden layers
            num_layers: int, number of hidden layers
        """
        super().__init__()

        #raise NotImplementedError("MLPClassifierDeep.__init__() is not implemented")
        layers = []
        n_in = h * w * 3

        # Dynamically add the specified number of hidden layers
        for _ in range(num_layers):
            layers.append(nn.Linear(n_in, hidden_dim))
            layers.append(nn.ReLU())
            n_in = hidden_dim  # The input size for the next layer becomes hidden_dim

        # Add the final output layer mapping to num_classes
        layers.append(nn.Linear(n_in, num_classes))

        # Combine all layers into a sequential container
        self.network = nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: tensor (b, 3, H, W) image

        Returns:
            tensor (b, num_classes) logits
        """
        #raise NotImplementedError("MLPClassifierDeep.forward() is not implemented")
        x = x.flatten(1)
        return self.network(x)


class MLPClassifierDeepResidual(nn.Module):
    def __init__(
        self,
        h: int = 64,
        w: int = 64,
        num_classes: int = 6,
    ):
        """
        Args:
            h: int, height of image
            w: int, width of image
            num_classes: int

        Hint - you can add more arguments to the constructor such as:
            hidden_dim: int, size of hidden layers
            num_layers: int, number of hidden layers
        """
        super().__init__()

        raise NotImplementedError("MLPClassifierDeepResidual.__init__() is not implemented")

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: tensor (b, 3, H, W) image

        Returns:
            tensor (b, num_classes) logits
        """
        raise NotImplementedError("MLPClassifierDeepResidual.forward() is not implemented")


model_factory = {
    "linear": LinearClassifier,
    "mlp": MLPClassifier,
    "mlp_deep": MLPClassifierDeep,
    "mlp_deep_residual": MLPClassifierDeepResidual,
}


def calculate_model_size_mb(model: torch.nn.Module) -> float:
    """
    Args:
        model: torch.nn.Module

    Returns:
        float, size in megabytes
    """
    return sum(p.numel() for p in model.parameters()) * 4 / 1024 / 1024


def save_model(model):
    """
    Use this function to save your model in train.py
    """
    for n, m in model_factory.items():
        if isinstance(model, m):
            return torch.save(model.state_dict(), Path(__file__).resolve().parent / f"{n}.th")
    raise ValueError(f"Model type '{str(type(model))}' not supported")


def load_model(model_name: str, with_weights: bool = False, **model_kwargs):
    """
    Called by the grader to load a pre-trained model by name
    """
    r = model_factory[model_name](**model_kwargs)
    if with_weights:
        model_path = Path(__file__).resolve().parent / f"{model_name}.th"
        assert model_path.exists(), f"{model_path.name} not found"
        try:
            r.load_state_dict(torch.load(model_path, map_location="cpu"))
        except RuntimeError as e:
            raise AssertionError(
                f"Failed to load {model_path.name}, make sure the default model arguments are set correctly"
            ) from e

    # Limit model sizes since they will be zipped and submitted
    model_size_mb = calculate_model_size_mb(r)
    if model_size_mb > 10:
        raise AssertionError(f"{model_name} is too large: {model_size_mb:.2f} MB")
    print(f"Model size: {model_size_mb:.2f} MB")

    return r
